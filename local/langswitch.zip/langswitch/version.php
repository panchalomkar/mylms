<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_langswitch';
$plugin->version   = 2024010103;
$plugin->requires  = 2022041900;
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = '1.0';
