<?php
require_once('../../config.php');
require_login();

header('Content-Type: application/json');

$current = optional_param('current', 0, PARAM_INT);
if ($current) {
    global $SESSION;
    echo json_encode(['lang' => $SESSION->lang ?? 'en']);
    exit;
}

require_sesskey();

$lang    = required_param('lang', PARAM_ALPHA);
$allowed = ['en', 'hi', 'mr', 'gu'];

if (!in_array($lang, $allowed)) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid language']);
    exit;
}

// ✅ Save to USER preference (permanent)
set_user_preference('local_langswitch_lang', $lang);

// ✅ Save to SESSION (current session)
$SESSION->lang = $lang;

// ✅ Save to COOKIE (available before session on next load)
setcookie(
    'moodle_langswitch',  // cookie name
    $lang,                // value
    [
        'expires'  => time() + (365 * 24 * 60 * 60), // 1 year
        'path'     => '/',
        'secure'   => isset($_SERVER['HTTPS']),
        'httponly' => true,
        'samesite' => 'Lax',
    ]
);

echo json_encode(['status' => 'ok', 'lang' => $lang]);