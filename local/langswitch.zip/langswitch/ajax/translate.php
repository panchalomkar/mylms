<?php
require_once('../../../config.php');
require_login();
require_sesskey();

header('Content-Type: application/json');

// ── Get OpenAI key from Moodle config.php ────────────────────────────────────
// Add this line to your config.php:
//   $CFG->openai_api_key = 'sk-xxxxxxxxxxxxxxxxxxxxxxxx';
//
if (empty($CFG->openai_api_key)) {
    echo json_encode(['error' => 'OpenAI API key not set in config.php. Add: $CFG->openai_api_key = "sk-xxx...";']);
    exit;
}

$openai_key = $CFG->openai_api_key;

// ── Params ────────────────────────────────────────────────────────────────────
$texts = required_param('texts', PARAM_RAW);
$lang  = required_param('lang',  PARAM_ALPHA);

$allowed = ['hi', 'mr', 'gu', 'en'];
if (!in_array($lang, $allowed)) {
    echo json_encode(['error' => 'Invalid language']);
    exit;
}

$langnames = [
    'en' => 'English',
    'hi' => 'Hindi',
    'mr' => 'Marathi',
    'gu' => 'Gujarati',
];

$texts_array = json_decode($texts, true);
if (!$texts_array || !is_array($texts_array)) {
    echo json_encode(['error' => 'Invalid texts input']);
    exit;
}

// Remove empty / too short texts
$texts_array = array_values(array_filter($texts_array, function($t) {
    return strlen(trim($t)) > 1;
}));

if (empty($texts_array)) {
    echo json_encode(['translations' => [], 'source' => 'empty']);
    exit;
}

// ── File cache ────────────────────────────────────────────────────────────────
$cachedir  = __DIR__ . '/../translations/';
$cachefile = $cachedir . $lang . '_cache.json';

$cache = [];
if (file_exists($cachefile)) {
    $decoded = json_decode(file_get_contents($cachefile), true);
    $cache   = is_array($decoded) ? $decoded : [];
}

// Split: cached vs needs translation
$need_translation = [];
$result           = [];

foreach ($texts_array as $text) {
    $key = md5(trim($text));
    if (isset($cache[$key])) {
        $result[$text] = $cache[$key];
    } else {
        $need_translation[] = $text;
    }
}

// All in cache — return immediately
if (empty($need_translation)) {
    echo json_encode(['translations' => $result, 'source' => 'cache']);
    exit;
}

// ── OpenAI API call ───────────────────────────────────────────────────────────
$target_lang = $langnames[$lang];

$prompt = "You are a translation engine for a Learning Management System (LMS) UI.
Translate the following UI texts to {$target_lang}.

STRICT RULES:
1. Return ONLY a valid JSON object. No explanation, no markdown, no extra text.
2. Format: {\"original text\": \"translated text\", ...}
3. Keep translations short and natural for UI labels, buttons, headings.
4. Preserve numbers, emojis, special characters exactly as-is.
5. If a text is already in {$target_lang}, return it unchanged.
6. Do NOT translate proper nouns, brand names, email addresses, URLs.
7. Do NOT translate single letters or numbers.

Texts:
" . json_encode($need_translation, JSON_UNESCAPED_UNICODE);

$payload = [
    'model'       => 'gpt-4o-mini',
    'messages'    => [
        [
            'role'    => 'system',
            'content' => 'You are a UI translation engine. Always respond with valid JSON only. No markdown, no explanation.'
        ],
        [
            'role'    => 'user',
            'content' => $prompt
        ]
    ],
    'temperature' => 0.1,
    'max_tokens'  => 2000,
];

$ch = curl_init('https://api.openai.com/v1/chat/completions');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $openai_key,
    ],
    CURLOPT_POSTFIELDS => json_encode($payload),
    CURLOPT_TIMEOUT    => 30,
]);

$response = curl_exec($ch);
$curl_err  = curl_error($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($curl_err) {
    echo json_encode(['error' => 'CURL error: ' . $curl_err]);
    exit;
}

if ($http_code !== 200) {
    echo json_encode(['error' => 'OpenAI HTTP error: ' . $http_code, 'raw' => $response]);
    exit;
}

$data = json_decode($response, true);

if (!isset($data['choices'][0]['message']['content'])) {
    echo json_encode(['error' => 'Unexpected OpenAI response', 'raw' => $data]);
    exit;
}

// ── Parse response ────────────────────────────────────────────────────────────
$content = $data['choices'][0]['message']['content'];

// Strip markdown code fences if present
$content = preg_replace('/^```(?:json)?\s*/i', '', trim($content));
$content = preg_replace('/\s*```$/', '', $content);

$translations = json_decode(trim($content), true);

if (!is_array($translations)) {
    echo json_encode(['error' => 'Failed to parse OpenAI response as JSON', 'raw' => $content]);
    exit;
}

// ── Merge + save cache ────────────────────────────────────────────────────────
foreach ($translations as $original => $translated) {
    $result[$original] = $translated;
    $cache[md5(trim($original))] = $translated;
}

// Ensure cache directory exists
if (!is_dir($cachedir)) {
    mkdir($cachedir, 0777, true);
}

file_put_contents(
    $cachefile,
    json_encode($cache, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)
);

echo json_encode([
    'translations' => $result,
    'source'       => 'openai',
    'count'        => count($translations),
]);
