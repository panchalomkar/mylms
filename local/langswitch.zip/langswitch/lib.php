<?php
defined('MOODLE_INTERNAL') || die();

/**
 * Runs on every page load — sets language from user saved preference.
 */

function local_langswitch_after_config() {
    global $SESSION, $USER, $CFG;

    $allowed = ['en', 'hi', 'mr', 'gu'];
    $lang    = 'en'; // default

    // ── Step 1: Check if user is logged in ──────────────────────────
    if (!empty($USER->id) && !isguestuser()) {

        // Logged in — trust DB preference over cookie
        $db_lang = get_user_preferences('local_langswitch_lang', '', $USER->id);

        if (!empty($db_lang) && in_array($db_lang, $allowed)) {
            $lang = $db_lang;

            // Sync cookie to match DB preference
            setcookie(
                'moodle_langswitch',
                $lang,
                [
                    'expires'  => time() + (365 * 24 * 60 * 60),
                    'path'     => '/',
                    'secure'   => isset($_SERVER['HTTPS']),
                    'httponly' => true,
                    'samesite' => 'Lax',
                ]
            );
        } else {
            // User has no preference saved — use English and clear cookie
            $lang = 'en';
            setcookie(
                'moodle_langswitch',
                '',
                [
                    'expires'  => time() - 3600,
                    'path'     => '/',
                    'secure'   => isset($_SERVER['HTTPS']),
                    'httponly' => true,
                    'samesite' => 'Lax',
                ]
            );
        }

    } else {
        // ── Step 2: Not logged in — use cookie (for login page) ─────
        $cookie_lang = isset($_COOKIE['moodle_langswitch'])
            ? clean_param($_COOKIE['moodle_langswitch'], PARAM_ALPHA)
            : 'en';

        if (in_array($cookie_lang, $allowed)) {
            $lang = $cookie_lang;
        }
    }

    // Apply language
    $SESSION->lang = $lang;

    if (function_exists('force_current_language')) {
        force_current_language($lang);
    }
}
/**
 * Fires when user logs out — clear language cookie.
 */
function local_langswitch_user_logout() {
    // Clear the language cookie on logout
    setcookie(
        'moodle_langswitch',
        '',
        [
            'expires'  => time() - 3600, // expired in past = delete
            'path'     => '/',
            'secure'   => isset($_SERVER['HTTPS']),
            'httponly' => true,
            'samesite' => 'Lax',
        ]
    );
    unset($_COOKIE['moodle_langswitch']);
}
/**
 * Add meta tags + early inline script to prevent Chrome's
 * native translate popup from appearing on any page.
 */
function local_langswitch_before_standard_html_head() {
    return '<meta name="google" content="notranslate">'
         . '<meta http-equiv="Content-Language" content="en">'
         . '<script>document.documentElement.setAttribute("translate","no");</script>';
}
/**
 * Inject auto-translator JS before footer on every page.
 */
function local_langswitch_before_footer() {
    global $PAGE, $SESSION, $CFG;

    $lang    = $SESSION->lang ?? 'en';
    $wwwroot = $CFG->wwwroot;
    $sesskey = sesskey();

    local_langswitch_inject_ui();

    if ($lang === 'en') return;

    // ✅ Add this — hide body until translation applied
    $hide_js = <<<JS
(function() {
    // Hide body immediately to prevent English flash
    document.documentElement.style.visibility = 'hidden';

    // Safety net — show after 2 seconds even if translation fails
    var safetyTimer = setTimeout(function() {
        document.documentElement.style.visibility = 'visible';
    }, 2000);

    // Expose function for translator to call when done
    window.langSwitchReady = function() {
        clearTimeout(safetyTimer);
        document.documentElement.style.visibility = 'visible';
    };
})();
JS;


    $js = <<<JS
(function() {

    const LANG      = '{$lang}';
    const WWWROOT   = '{$wwwroot}';
    const SESSKEY   = '{$sesskey}';
    const CACHE_KEY = 'langswitch_' + LANG;
    const CACHE_VER = 'v3';

    // ── Guards against repeated / duplicate translation work ──────────
    // A text node, once collected, is marked "handled" immediately — even
    // before its translation comes back. This stops the loop where the
    // translated text itself (e.g. Hindi) gets picked up as "new" content
    // by MutationObservers (esp. the calendar/timeline ones that watch
    // characterData) and re-sent to the API forever.
    const translatedTextNodes = new WeakSet(); // Text nodes already handled
    const inFlightTexts       = new Map();     // text -> array of waiting callbacks (dedupes concurrent API calls)

    // ── Tags to skip ─────────────────────────────────────────────────
const SKIP_TAGS = new Set([
    'SCRIPT','STYLE','NOSCRIPT','IFRAME',
    'INPUT','TEXTAREA','CODE','PRE',
    'HEAD','META','LINK','TITLE'
    // ✅ SELECT and OPTION removed — dropdown text now translatable
]);

const SKIP_SELECTORS = [
    '[data-no-translate]',
    '.no-translate',
    '.lang-switcher-widget',
    '.lang-switcher-btn',
    // ✅ Material Icons — must never be translated
    '.material-icons',
    '.material-icons-outlined',
    '.material-icons-round',
    '.material-icons-sharp',
    '.material-icons-two-tone',
    '.material-symbols-rounded',
    '.material-symbols-outlined',
    '.material-symbols-sharp',
    // ✅ Font Awesome
    '.fa',
    '.fas',
    '.far',
    '.fab',
    '.fal',
    // ✅ Other common icon libraries
    '.glyphicon',
    '[class*="icon-"]',
];

    // ── Load cache ───────────────────────────────────────────────────
    function getCache() {
        try {
            const raw = localStorage.getItem(CACHE_KEY);
            if (!raw) return {};
            const obj = JSON.parse(raw);
            if (obj.__ver !== CACHE_VER) return {};
            return obj;
        } catch(e) { return {}; }
    }

    function saveCache(cache) {
        try {
            cache.__ver = CACHE_VER;
            localStorage.setItem(CACHE_KEY, JSON.stringify(cache));
        } catch(e) {}
    }

    // ── Collect visible text nodes ───────────────────────────────────
    function collectTextNodes(root) {
        root = root || document.body;
        const walker = document.createTreeWalker(
            root,
            NodeFilter.SHOW_TEXT,
            {
                acceptNode: function(node) {
                    const text   = node.nodeValue.trim();
                    const parent = node.parentElement;

                    if (!text || text.length < 2)
                        return NodeFilter.FILTER_REJECT;

                    // ✅ Skip nodes we've already translated (prevents the
                    // "already-translated text keeps getting re-sent" loop)
                    if (translatedTextNodes.has(node))
                        return NodeFilter.FILTER_REJECT;

                    // Skip pure numbers / symbols / URLs / emails
                  // ✅ Skip Material Icon ligature names (snake_case words)
if (/^[a-z][a-z0-9_]+$/.test(text))
    return NodeFilter.FILTER_REJECT;

// ✅ Skip all-uppercase short strings (abbreviations/codes)
if (/^[A-Z0-9_]{1,10}$/.test(text))
    return NodeFilter.FILTER_REJECT;

                    if (/^https?:\/\//.test(text))
                        return NodeFilter.FILTER_REJECT;

                    if (!parent || SKIP_TAGS.has(parent.tagName))
                        return NodeFilter.FILTER_REJECT;

                    for (const sel of SKIP_SELECTORS) {
                        try {
                            if (parent.closest(sel))
                                return NodeFilter.FILTER_REJECT;
                        } catch(e) {}
                    }

                    return NodeFilter.FILTER_ACCEPT;
                }
            }
        );

        const nodes = [];
        let node;
        while ((node = walker.nextNode())) {
            nodes.push(node);
        }
        return nodes;
    }
// ── Collect <option> elements separately (dropdown text) ─────────
function collectOptionElements(root) {
    root = root || document.body;
    const options = root.querySelectorAll('option');
    const items = [];

    options.forEach(function(opt) {
        // ✅ Skip options we've already translated
        if (opt.dataset.lsDone === '1') return;

        const text = opt.textContent.trim();
        if (text && text.length > 1 && !/^[\d\s\.\,\:\-\+\%\#\/\\@\_\(\)]+$/.test(text)) {
            items.push(opt); // store the element itself, not a text node
        }
    });

    return items;
}

// ── Apply translations to <option> elements ───────────────────────
function applyOptionTranslations(optionElements, translations) {
    optionElements.forEach(function(opt) {
        const original = opt.textContent.trim();
        if (translations[original]) {
            opt.textContent = translations[original];
        }
    });
}
// ── Collect input placeholders ────────────────────────────────────
function collectPlaceholders(root) {
    root = root || document.body;
    const inputs = root.querySelectorAll('input[placeholder], textarea[placeholder]');
    const items = [];
    inputs.forEach(function(el) {
        // ✅ Skip placeholders we've already translated
        if (el.dataset.lsPhDone === '1') return;

        const text = el.getAttribute('placeholder');
        if (text && text.trim().length > 1) {
            items.push(el);
        }
    });
    return items;
}

// ── Apply translations to placeholders ─────────────────────────────
function applyPlaceholderTranslations(elements, translations) {
    elements.forEach(function(el) {
        const original = el.getAttribute('placeholder').trim();
        if (translations[original]) {
            el.setAttribute('placeholder', translations[original]);
        }
    });
}

// ── Process placeholders through cache + API ────────────────────────
function processPlaceholders(elements) {
    if (!elements || elements.length === 0) return;

    // ✅ Mark handled immediately — same reasoning as processNodes.
    elements.forEach(function(el) { el.dataset.lsPhDone = '1'; });

    const allTexts = [...new Set(elements.map(function(el) {
        return el.getAttribute('placeholder').trim();
    }))];

    fetchTranslations(allTexts, function(translations) {
        applyPlaceholderTranslations(elements, translations);
    });
}
    // ── Apply translations to nodes ──────────────────────────────────
    function applyTranslations(nodes, translations) {
        nodes.forEach(function(node) {
            const original = node.nodeValue.trim();
            if (translations[original]) {
                node.nodeValue = node.nodeValue.replace(
                    original,
                    translations[original]
                );
            }
        });
    }

    // ── Call translate.php → OpenAI ──────────────────────────────────
    function translateViaAPI(texts, callback) {
        if (!texts || texts.length === 0) return;

        fetch(WWWROOT + '/local/langswitch/ajax/translate.php', {
            method  : 'POST',
            headers : { 'Content-Type': 'application/x-www-form-urlencoded' },
            body    : 'texts='    + encodeURIComponent(JSON.stringify(texts))
                    + '&lang='    + LANG
                    + '&sesskey=' + SESSKEY
        })
        .then(function(r) { return r.json(); })
        .then(function(data) {
            if (data.translations) {
                callback(data.translations);
            } else {
                if (data.error) console.warn('LangSwitch error:', data.error);
                // ✅ Always resolve — even empty — so in-flight guards
                // clear and this text can be retried on a future request
                // instead of getting stuck forever.
                callback({});
            }
        })
        .catch(function(err) {
            console.warn('LangSwitch API error:', err);
            callback({});
        });
    }

    // ── Central translation resolver: cache + deduped/batched API ────
    // Any caller asks for a list of texts and gets called back once with
    // a { originalText: translatedText } map. If two callers ask for the
    // same uncached text at (roughly) the same time, only ONE network
    // request goes out — the second caller just waits on the first.
    function fetchTranslations(texts, onDone) {
        const cache  = getCache();
        const result = {};
        const need   = [];

        texts.forEach(function(text) {
            if (cache[text] && cache[text] !== text) {
                result[text] = cache[text];
            } else if (need.indexOf(text) === -1) {
                need.push(text);
            }
        });

        if (need.length === 0) {
            onDone(result);
            return;
        }

        let remaining = need.length;
        function noteDone(text, translations) {
            if (translations && translations[text]) result[text] = translations[text];
            remaining--;
            if (remaining <= 0) onDone(result);
        }

        // Split into texts we need to actually request vs. ones already
        // being fetched by some other caller right now.
        const toRequest = [];
        need.forEach(function(text) {
            if (inFlightTexts.has(text)) {
                inFlightTexts.get(text).push(function(translations) { noteDone(text, translations); });
            } else {
                inFlightTexts.set(text, [function(translations) { noteDone(text, translations); }]);
                toRequest.push(text);
            }
        });

        if (toRequest.length === 0) return; // everything was already in-flight

        const BATCH = 50;
        for (let i = 0; i < toRequest.length; i += BATCH) {
            const batch = toRequest.slice(i, i + BATCH);

            translateViaAPI(batch, function(translations) {
                if (Object.keys(translations).length > 0) {
                    const updatedCache = getCache();
                    Object.assign(updatedCache, translations);
                    saveCache(updatedCache);
                }

                batch.forEach(function(text) {
                    const waiters = inFlightTexts.get(text) || [];
                    inFlightTexts.delete(text);
                    waiters.forEach(function(fn) { fn(translations); });
                });
            });
        }
    }

    // ── Process nodes: cache + API ───────────────────────────────────
function processNodes(nodes) {
    if (!nodes || nodes.length === 0) {
        // Nothing to translate — show page
        if (window.langSwitchReady) window.langSwitchReady();
        return;
    }

    // ✅ Mark handled immediately — before the translation even comes
    // back — so no future rescan (mutation observer, timer, modal
    // watcher, etc.) ever re-collects these exact node instances.
    nodes.forEach(function(n) { translatedTextNodes.add(n); });

    const allTexts = [...new Set(nodes.map(function(n) {
        return n.nodeValue.trim();
    }).filter(function(t) { return t.length > 1; }))];

    if (allTexts.length === 0) {
        if (window.langSwitchReady) window.langSwitchReady();
        return;
    }

    fetchTranslations(allTexts, function(translations) {
        applyTranslations(nodes, translations);
        if (window.langSwitchReady) window.langSwitchReady();
    });
}
    // ── Main run ─────────────────────────────────────────────────────
function run() {
    const nodes = collectTextNodes(document.body);
    processNodes(nodes);

    const optionEls = collectOptionElements(document.body);
    processOptionElements(optionEls);

    // ✅ NEW — placeholders
    const placeholderEls = collectPlaceholders(document.body);
    processPlaceholders(placeholderEls);
}

// ── Process <option> elements through cache + API ─────────────────
function processOptionElements(optionElements) {
    if (!optionElements || optionElements.length === 0) return;

    // ✅ Mark handled immediately — same reasoning as processNodes.
    optionElements.forEach(function(el) { el.dataset.lsDone = '1'; });

    const allTexts = [...new Set(optionElements.map(function(el) {
        return el.textContent.trim();
    }))];

    fetchTranslations(allTexts, function(translations) {
        applyOptionTranslations(optionElements, translations);
    });
}
/**
 * Add meta tag to prevent browser auto-translate popup.
 */

    // ── DOM ready ────────────────────────────────────────────────────
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', run);
    } else {
        run();
    }

    // ── Watch for AJAX / dynamic content ─────────────────────────────
    let debounceTimer = null;
const observer = new MutationObserver(function(mutations) {
    const newNodes = [];
    const newOptions = [];
    const newPlaceholders = [];

    mutations.forEach(function(m) {
        m.addedNodes.forEach(function(n) {
            if (n.nodeType === 1 && !SKIP_TAGS.has(n.tagName)) {
                newNodes.push(...collectTextNodes(n));
                newOptions.push(...collectOptionElements(n));
                newPlaceholders.push(...collectPlaceholders(n));
            }
        });
    });

    if (newNodes.length > 0 || newOptions.length > 0 || newPlaceholders.length > 0) {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(function() {
            if (newNodes.length > 0) processNodes(newNodes);
            if (newOptions.length > 0) processOptionElements(newOptions);
            if (newPlaceholders.length > 0) processPlaceholders(newPlaceholders);
        }, 800);
    }
});

    if (document.body) {
        observer.observe(document.body, {
            childList : true,
            subtree   : true
        });
    }
// ── Extra watcher for Bootstrap modals (popups) ────────────────────
if (window.jQuery) {
    jQuery(document).on('shown.bs.modal', function(e) {
        setTimeout(function() {
            const modalNodes = collectTextNodes(e.target);
            const modalOptions = collectOptionElements(e.target);
            const modalPlaceholders = collectPlaceholders(e.target);
            if (modalNodes.length > 0) processNodes(modalNodes);
            if (modalOptions.length > 0) processOptionElements(modalOptions);
            if (modalPlaceholders.length > 0) processPlaceholders(modalPlaceholders);
        }, 200);
    });
}
// ── Watcher specifically for Moodle calendar AJAX re-renders ───────
const calendarContainer = document.querySelector('[data-region="calendar"]') 
                        || document.querySelector('.block_calendar_month')
                        || document.querySelector('.calendarwrapper');

if (calendarContainer) {
    const calendarObserver = new MutationObserver(function() {
        clearTimeout(calendarContainer._langDebounce);
        calendarContainer._langDebounce = setTimeout(function() {
            if (window.langSwitchRescan) {
                window.langSwitchRescan(calendarContainer);
            }
        }, 300);
    });

    calendarObserver.observe(calendarContainer, {
        childList: true,
        subtree: true,
        characterData: true
    });
}
// ── Timeline block + Calendar safety rescan (covers async Moodle renders) ──
function rescanKnownDynamicBlocks() {
    const selectors = [
        '[data-region="timeline-view-selector"]',
        '.block_timeline',
        '#timeline-view',
        '[data-region="calendar"]',
        '.block_calendar_month',
        '.calendarwrapper',
        '[data-region="event-list-wrapper"]',
    ];

    selectors.forEach(function(sel) {
        const el = document.querySelector(sel);
        if (el && window.langSwitchRescan) {
            window.langSwitchRescan(el);
        }
    });
}
// ── Defensive rescan for sidebar block headers (My Profile, My Calendar, etc.) ──
function rescanBlockHeaders() {
    const headers = document.querySelectorAll(
        '.myprofile-title, .myprofile-header h5, [class*="block-header"] h5, [class*="block-header"] h3'
    );
    headers.forEach(function(el) {
        if (window.langSwitchRescan) {
            window.langSwitchRescan(el);
        }
    });
}

[300, 1000, 2000].forEach(function(delay) {
    setTimeout(rescanBlockHeaders, delay);
});
// Run repeatedly as Moodle's AMD modules render asynchronously
[300, 800, 1500, 2500, 4000].forEach(function(delay) {
    setTimeout(rescanKnownDynamicBlocks, delay);
});

// Watch these specific blocks for any future re-renders (AJAX month nav, filter changes)
['[data-region="timeline-view-selector"]', '.block_timeline', '[data-region="calendar"]', '.block_calendar_month', '.calendarwrapper']
    .forEach(function(sel) {
        const el = document.querySelector(sel);
        if (el) {
            const obs = new MutationObserver(function() {
                clearTimeout(el._langDebounce);
                el._langDebounce = setTimeout(function() {
                    if (window.langSwitchRescan) window.langSwitchRescan(el);
                }, 300);
            });
            obs.observe(el, { childList: true, subtree: true, attributes: true, characterData: true });
        }
    });
// Expose manual rescan for any custom modal/popup implementation
window.langSwitchRescan = function(root) {
    root = root || document.body;
    const nodes = collectTextNodes(root);
    const opts  = collectOptionElements(root);
    const phs   = collectPlaceholders(root);
    if (nodes.length > 0) processNodes(nodes);
    if (opts.length > 0) processOptionElements(opts);
    if (phs.length > 0) processPlaceholders(phs);
};
})();
JS;

    $PAGE->requires->js_init_code($js);
}

/**
 * Inject the floating language switcher UI widget.
 */
function local_langswitch_inject_ui() {
    global $PAGE, $SESSION, $CFG;

    $current = $SESSION->lang ?? 'en';
    $wwwroot = $CFG->wwwroot;
    $sesskey = sesskey();

    // Pre-compute active classes in PHP — avoids === inside heredoc
    $active_en = ($current === 'en') ? 'active' : '';
    $active_hi = ($current === 'hi') ? 'active' : '';
    $active_mr = ($current === 'mr') ? 'active' : '';
    $active_gu = ($current === 'gu') ? 'active' : '';

    $ui_js = <<<JS

(function() {
    document.addEventListener('DOMContentLoaded', function() {
  // Prevent Chrome auto-translate popup (body now exists)
        document.documentElement.setAttribute('translate', 'no');
        document.documentElement.classList.add('notranslate');
        document.body.setAttribute('translate', 'no');
        document.body.classList.add('notranslate');
        // Create floating switcher widget
        const widget = document.createElement('div');
        widget.className = 'lang-switcher-widget';
        widget.innerHTML = '<div class="lang-switcher-inner">'
            + '<span class="lang-switcher-icon" title="Drag to move">🌐</span>'
            + '<div class="lang-switcher-buttons">'
            + '<button class="lang-switcher-btn {$active_en}" data-lang="en">EN</button>'
            + '<button class="lang-switcher-btn {$active_hi}" data-lang="hi">हि</button>'
            + '<button class="lang-switcher-btn {$active_mr}" data-lang="mr">म</button>'
            + '<button class="lang-switcher-btn {$active_gu}" data-lang="gu">ગુ</button>'
            + '</div>'
            + '</div>';

        // Styles
        const style = document.createElement('style');
        style.textContent = `
            .lang-switcher-widget {
                position: fixed;
                bottom: 24px;
                right: 24px;
                z-index: 99999;
                background: #003152;
                border-radius: 50px;
                padding: 6px 12px;
                box-shadow: 0 4px 15px rgba(0,0,0,0.3);
                display: flex;
                align-items: center;
                gap: 6px;
                user-select: none;
            }
            .lang-switcher-widget.lang-switcher-dragging {
                box-shadow: 0 8px 28px rgba(0,0,0,0.45);
                opacity: 0.92;
                cursor: grabbing;
            }
            .lang-switcher-inner {
                display: flex;
                align-items: center;
                gap: 8px;
            }
            .lang-switcher-icon {
                font-size: 18px;
                cursor: grab;
                touch-action: none;
                line-height: 1;
                padding: 2px;
            }
            .lang-switcher-icon:active {
                cursor: grabbing;
            }
            .lang-switcher-buttons {
                display: flex;
                gap: 4px;
            }
            .lang-switcher-btn {
                background: transparent;
                border: 1px solid rgba(255,255,255,0.3);
                color: #fff;
                border-radius: 20px;
                padding: 3px 10px;
                font-size: 12px;
                cursor: pointer;
                transition: all 0.2s;
                font-weight: 500;
            }
            .lang-switcher-btn:hover {
                background: rgba(255,255,255,0.2);
            }
            .lang-switcher-btn.active {
                background: #ec9707;
                border-color: #ec9707;
                font-weight: 700;
            }
            .lang-switcher-loading {
                opacity: 0.6;
                pointer-events: none;
            }
        `;
        document.head.appendChild(style);
        document.body.appendChild(widget);

        // ── Drag to move (handle = the 🌐 icon, so language buttons stay clickable) ──
        (function initDrag() {
            const handle = widget.querySelector('.lang-switcher-icon');
            const POS_KEY = 'langswitch_widget_pos';

            let dragging  = false;
            let startX, startY, startLeft, startTop;

            function clamp(left, top) {
                const rect = widget.getBoundingClientRect();
                const maxLeft = Math.max(4, window.innerWidth  - rect.width  - 4);
                const maxTop  = Math.max(4, window.innerHeight - rect.height - 4);
                return {
                    left: Math.min(Math.max(4, left), maxLeft),
                    top : Math.min(Math.max(4, top),  maxTop)
                };
            }

            function setPosition(left, top) {
                const pos = clamp(left, top);
                widget.style.left   = pos.left + 'px';
                widget.style.top    = pos.top + 'px';
                widget.style.right  = 'auto';
                widget.style.bottom = 'auto';
            }

            // Restore last saved position, if any and still on-screen.
            try {
                const saved = JSON.parse(localStorage.getItem(POS_KEY) || 'null');
                if (saved && typeof saved.left === 'number' && typeof saved.top === 'number') {
                    setPosition(saved.left, saved.top);
                }
            } catch(e) {}

            function onPointerDown(e) {
                dragging = true;
                const rect = widget.getBoundingClientRect();
                startLeft = rect.left;
                startTop  = rect.top;
                startX    = e.clientX;
                startY    = e.clientY;
                setPosition(startLeft, startTop);
                widget.classList.add('lang-switcher-dragging');
                try { handle.setPointerCapture(e.pointerId); } catch(err) {}
                e.preventDefault();
            }

            function onPointerMove(e) {
                if (!dragging) return;
                setPosition(startLeft + (e.clientX - startX), startTop + (e.clientY - startY));
            }

            function onPointerUp() {
                if (!dragging) return;
                dragging = false;
                widget.classList.remove('lang-switcher-dragging');
                const rect = widget.getBoundingClientRect();
                try {
                    localStorage.setItem(POS_KEY, JSON.stringify({ left: rect.left, top: rect.top }));
                } catch(e) {}
            }

            handle.addEventListener('pointerdown', onPointerDown);
            window.addEventListener('pointermove', onPointerMove);
            window.addEventListener('pointerup', onPointerUp);
            window.addEventListener('pointercancel', onPointerUp);

            // Keep the widget on-screen if the viewport is resized (e.g. rotate phone).
            window.addEventListener('resize', function() {
                if (widget.style.left && widget.style.left !== 'auto') {
                    const rect = widget.getBoundingClientRect();
                    setPosition(rect.left, rect.top);
                }
            });
        })();

        // Handle button clicks
        widget.querySelectorAll('.lang-switcher-btn').forEach(function(btn) {
            btn.addEventListener('click', function() {
                const lang = this.getAttribute('data-lang');

                // Visual feedback
                widget.classList.add('lang-switcher-loading');
                widget.querySelectorAll('.lang-switcher-btn').forEach(function(b) {
                    b.classList.remove('active');
                });
                this.classList.add('active');
                this.textContent = '...';

                // Clear translation cache for new language
                try {
                    localStorage.removeItem('langswitch_' + lang);
                } catch(e) {}

                // Save to server
                fetch('{$wwwroot}/local/langswitch/switch.php', {
                    method  : 'POST',
                    headers : { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body    : 'lang=' + lang + '&sesskey={$sesskey}'
                })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (data.status === 'ok') {
                        location.reload();
                    }
                })
                .catch(function(err) {
                    console.warn('Lang switch error:', err);
                    widget.classList.remove('lang-switcher-loading');
                });
            });
        });
    });
})();
JS;

    $PAGE->requires->js_init_code($ui_js);
}