<?php
// local/siteguard/lib.php
defined('MOODLE_INTERNAL') || die();

// Hook callbacks moved to classes/hooks/after_config.php
// This file intentionally left without after_config() function.