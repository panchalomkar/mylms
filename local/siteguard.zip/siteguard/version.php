<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_siteguard';
$plugin->version   = 2024010102;
$plugin->requires  = 2025040400;   // Moodle 5.0 minimum
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = '1.0';

// below for version 4.1

// $plugin->component = 'local_siteguard';
// $plugin->version   = 2024010101;
// $plugin->requires  = 2022112800;   // Moodle 4.1 minimum
// $plugin->maturity  = MATURITY_STABLE;
// $plugin->release   = '1.0';