<?php
defined('MOODLE_INTERNAL') || die();

$callbacks = [
    [
        'hook'     => core\hook\after_config::class,
        'callback' => local_siteguard\hooks\after_config::class . '::callback',
        'priority' => 1000,   // higher = runs earlier
    ],
];