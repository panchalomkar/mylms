<?php
namespace local_siteguard\hooks;

defined('MOODLE_INTERNAL') || die();

class after_config {

    public static function callback(\core\hook\after_config $hook): void {

        // Skip CLI (cron, admin scripts)
        if (php_sapi_name() === 'cli') {
            return;
        }

        // Already logged in — allow through
        if (isloggedin() && !isguestuser()) {
            return;
        }

        $request = $_SERVER['REQUEST_URI'] ?? '';

        $allowed = [
            // ── Login & Auth ──────────────────────────────────────────
            '/login/index.php',
            '/login/forgot_password.php',
            '/login/signup.php',
            '/login/oauth2.php',
            '/login/token.php',
            '/login/change_password.php',
            '/login/confirm.php',

            // ── OAuth2 / SSO ──────────────────────────────────────────
            '/admin/oauth2callback.php',
            '/auth/oauth2/',
            '/auth/shibboleth/',
            '/auth/saml2/',
            '/auth/ldap/',
            '/auth/oidc/',
            '/auth/cas/',

            // ── Webservices & Mobile ──────────────────────────────────
            '/webservice/',
            '/webservice/rest/server.php',
            '/webservice/soap/server.php',
            '/webservice/xmlrpc/server.php',
            '/webservice/upload.php',
            '/webservice/pluginfile.php',
            '/local/mobile/',
            '/admin/tool/mobile/',

            // ── Core JS / AMD / AJAX ──────────────────────────────────
            '/lib/javascript.php',
            '/lib/requirejs.php',
            '/lib/ajax/',
            '/lib/fonts/',
            '/lib/amd/',
            '/lib/editor/',

            // ── Cache & Assets ────────────────────────────────────────
            '/cache/',
            '/pix/',

            // ── File Serving ──────────────────────────────────────────
            '/pluginfile.php',
            '/tokenpluginfile.php',
            '/draftfile.php',
            '/brokenfile.php',
            '/repository/',

            // ── H5P ──────────────────────────────────────────────────
            '/h5p/',
            '/lib/h5p/',

            // ── Media ─────────────────────────────────────────────────
            '/media/',

            // ── Theme / RemUI ─────────────────────────────────────────
            '/theme/',
            '/theme/remui/',
            '/theme/remui/pix/',
            '/theme/remui/fonts/',
            '/theme/remui/javascript/',
            '/theme/remui/vendor/',
            '/theme/remui/amd/',
            '/theme/remui/images/',
            '/theme/remui/style/',
            '/theme/remui/layout/',
            '/theme/remui/customizer/',
            '/local/edwiserbridge/',
            '/local/remui/',
            '/blocks/remui',

            // ── SCORM ─────────────────────────────────────────────────
            '/mod/scorm/datamodel.php',
            '/mod/scorm/player.php',

            // ── LTI ───────────────────────────────────────────────────
            '/mod/lti/',
            '/enrol/lti/',

            // ── Payments ──────────────────────────────────────────────
            '/payment/',
            '/enrol/paypal/ipn.php',
            '/enrol/stripe/',
            '/payment/gateway/paypal/',
            '/payment/gateway/stripe/',
            '/payment/gateway/razorpay/',
            '/enrol/razorpay/',
            '/enrol/paytm/',
            '/enrol/instamojo/',

            // ── Calendar / RSS / Badges ───────────────────────────────
            '/calendar/export.php',
            '/calendar/export_execute.php',
            '/rss/',
            '/badges/badge.php',
            '/badges/backpack-add.php',

            // ── Cron ──────────────────────────────────────────────────
            '/admin/cron.php',

            // ── Zoom ──────────────────────────────────────────────────
            '/mod/zoom/',
            '/mod/zoom/webhook.php',
            '/mod/zoom/callback.php',
            '/local/zoom/',

            // ── Google Meet / Workspace ───────────────────────────────
            '/mod/googlemeet/',
            '/repository/googledocs/',
            '/repository/gdrive/',

            // ── Microsoft 365 / Teams ─────────────────────────────────
            '/local/o365/',
            '/local/msaccount/',
            '/local/office365/',
            '/local/o365/oauth/',
            '/mod/msteams/',
            '/mod/teams/',
            '/repository/onedrive/',
            '/local/sharepoint/',

            // ── BigBlueButton ─────────────────────────────────────────
            '/mod/bigbluebuttonbn/',
            '/mod/bigbluebuttonbn/bbb_broker.php',

            // ── Turnitin / Plagiarism ─────────────────────────────────
            '/plagiarism/turnitin/',
            '/plagiarism/urkund/',
            '/mod/turnitintooltwo/',

            // ── Certificates ──────────────────────────────────────────
            '/mod/certificate/',
            '/mod/customcert/',
            '/mod/coursecertificate/',

            // ── Edwiser ───────────────────────────────────────────────
            '/local/edwiserchat/',
            '/blocks/edwiser_site_monitor/',

            // ── Webhooks / Zapier ─────────────────────────────────────
            '/local/webhooks/',
            '/webservice/restful/',

            // ── Antivirus ─────────────────────────────────────────────
            '/lib/antivirus/',
        ];

        foreach ($allowed as $path) {
            if (strpos($request, $path) !== false) {
                return;
            }
        }

        redirect(new \moodle_url('/login/index.php'));
    }
}