<?php
/**
 * Script for bulk user delete operations (Production Ready)
 */

require_once('../../../config.php');
require_once($CFG->libdir.'/adminlib.php');

require_login();
require_capability('moodle/user:delete', context_system::instance());

global $SESSION, $DB, $OUTPUT, $PAGE, $USER;

// ✅ Get confirm + sesskey
$confirm = optional_param('confirm', 0, PARAM_BOOL);

// ✅ 1. GET method (recommended)
$userids_param = optional_param('userids', '', PARAM_TEXT);
if (!empty($userids_param)) {
    $SESSION->bulk_users = array_filter(array_map('intval', explode(',', $userids_param)));
}

// ✅ 2. AJAX JSON fallback
$bulkjson = optional_param('bulk_action', '', PARAM_RAW);
if (!empty($bulkjson)) {
    $bulk = json_decode($bulkjson, true);
    if (!empty($bulk['data']) && is_array($bulk['data'])) {
        $SESSION->bulk_users = array_map('intval', $bulk['data']);
    }
}

// ✅ Return URL
$returnurl = !empty($SESSION->return)
    ? new moodle_url($SESSION->return)
    : new moodle_url('/local/people/index.php');

// ❌ No users
if (empty($SESSION->bulk_users) || !is_array($SESSION->bulk_users)) {
    redirect($returnurl, 'No users selected', 2);
}

// Page setup
$PAGE->set_url('/local/people/actions/user_bulk_delete.php');
$PAGE->set_pagelayout('admin');
echo $OUTPUT->header();

// Prepare user list
list($in, $params) = $DB->get_in_or_equal($SESSION->bulk_users);
$userlist = $DB->get_records_select_menu(
    'user',
    "id $in",
    $params,
    '',
    'id,' . $DB->sql_fullname() . ' AS fullname'
);

$usernames = implode(', ', $userlist);

// ================= DELETE LOGIC =================
if ($confirm && confirm_sesskey()) {

    $notifications = '';

    $rs = $DB->get_recordset_select('user', "id $in", $params);

    foreach ($rs as $user) {

        // ❌ Skip admin & self
        if (is_siteadmin($user) || $USER->id == $user->id) {
            $notifications .= $OUTPUT->notification(
                'Cannot delete: ' . fullname($user),
                'notifyproblem'
            );
            continue;
        }

        if (delete_user($user)) {
            unset($SESSION->bulk_users[$user->id]);
        } else {
            $notifications .= $OUTPUT->notification(
                'Failed to delete: ' . fullname($user),
                'notifyproblem'
            );
        }
    }

    $rs->close();
    \core\session\manager::gc();

    echo $OUTPUT->box_start('generalbox', 'notice');

    if (!empty($notifications)) {
        echo $notifications;
    } else {
        if (count($userlist) > 1) {
            echo $OUTPUT->notification(
                get_string('deleteconfirm1', 'local_people', $usernames),
                'notifysuccess'
            );
        } else {
            echo $OUTPUT->notification(
                get_string('deleteconfirm', 'local_people', $usernames),
                'notifysuccess'
            );
        }
    }

    // Continue button
    echo $OUTPUT->continue_button($returnurl);
    echo $OUTPUT->box_end();

} else {
    // ✅ Auto-confirm (no UI)
    if (!confirm_sesskey()) {
        throw new moodle_exception('invalidsesskey');
    }

    // Force delete
    redirect(
        new moodle_url('/local/people/actions/user_bulk_delete.php', [
            'confirm' => 1,
            'sesskey' => sesskey()
        ])
    );
}

echo $OUTPUT->footer();