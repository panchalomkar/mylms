<?php
// This file is part of Moodle - http://moodle.org/
// GNU General Public License v3 or later - https://www.gnu.org/licenses/gpl-3.0.html
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_halloffame';
$plugin->version   = 2025041000;
$plugin->requires  = 2024100700; // Moodle 5.0+
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = '1.1.0';
