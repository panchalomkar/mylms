<?php
define('AJAX_SCRIPT', true);

require_once('../../../config.php');
require_login();

global $DB;

header('Content-Type: application/json');

$id   = required_param('id', PARAM_INT);
$type = required_param('type', PARAM_ALPHA);

$sql = "SELECT u.id, u.firstname, u.lastname
        FROM {halloffame_likes} l
        JOIN {user} u ON u.id = l.userid
        WHERE l.itemid = :id AND l.itemtype = :type
        ORDER BY l.timecreated DESC";

$users = $DB->get_records_sql($sql, [
    'id' => $id,
    'type' => $type
]);

$result = [];

foreach ($users as $u) {
    $result[] = [
        'fullname' => fullname($u)
    ];
}

echo json_encode(array_values($result));
exit;