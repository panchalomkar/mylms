/**
 * Hall of Fame v3 – certificate popup AMD module.
 * Opens a modal when user clicks on a certificate image or PDF card.
 *
 * @module local_halloffame/certpopup
 */
define([], function() {
    'use strict';

    var _overlay = null;

    function init() {
        ensureOverlay();

        document.addEventListener('click', function(e) {
            var el = e.target.closest('.hof-cert-clickable');
            if (!el) return;
            e.preventDefault();
            e.stopPropagation();
            openPopup(el);
        });
    }

    function ensureOverlay() {
        if (_overlay) return;

        _overlay = document.createElement('div');
        _overlay.id        = 'hof-cert-overlay';
        _overlay.className = 'hof-cert-overlay';
        _overlay.setAttribute('role', 'dialog');
        _overlay.setAttribute('aria-modal', 'true');
        _overlay.setAttribute('aria-label', 'Certificate viewer');
        _overlay.innerHTML = ''
            + '<div class="hof-cert-popup">'
            + '  <div class="hof-cert-popup-header">'
            + '    <span class="hof-cert-popup-title" id="hof-cert-popup-title"></span>'
            + '    <div class="hof-cert-popup-actions">'
            + '      <a class="hof-cert-popup-download hof-btn hof-btn-sm hof-btn-primary"'
            + '         id="hof-cert-popup-download" target="_blank" rel="noopener noreferrer">'
            + '        <i class="fa fa-download" aria-hidden="true"></i> Download'
            + '      </a>'
            + '      <button class="hof-cert-popup-close" id="hof-cert-popup-close"'
            + '              aria-label="Close certificate viewer">'
            + '        <i class="fa fa-times" aria-hidden="true"></i>'
            + '      </button>'
            + '    </div>'
            + '  </div>'
            + '  <div class="hof-cert-popup-body" id="hof-cert-popup-body"></div>'
            + '</div>';

        document.body.appendChild(_overlay);

        // Close on overlay background click.
        _overlay.addEventListener('click', function(e) {
            if (e.target === _overlay) closePopup();
        });

        // Close button.
        document.getElementById('hof-cert-popup-close').addEventListener('click', closePopup);

        // Close on Escape key.
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') closePopup();
        });
    }

    function openPopup(el) {
        var fileurl     = el.dataset.fileurl || '';
        var title       = el.dataset.title   || 'Certificate';
        var fileisimage = el.dataset.fileisimage === '1';

        if (!fileurl) return;

        var titleEl    = document.getElementById('hof-cert-popup-title');
        var bodyEl     = document.getElementById('hof-cert-popup-body');
        var downloadEl = document.getElementById('hof-cert-popup-download');

        if (titleEl)    titleEl.textContent   = title;
        if (downloadEl) { downloadEl.href = fileurl; downloadEl.style.display = 'inline-flex'; }

        if (bodyEl) {
            if (fileisimage) {
                bodyEl.innerHTML = '<img src="' + esc(fileurl) + '" class="hof-cert-popup-img" alt="' + esc(title) + '"/>';
            } else {
                // PDF or other file — embed via iframe, with fallback download link.
                bodyEl.innerHTML = ''
                    + '<div class="hof-cert-popup-pdf-wrap">'
                    + '  <iframe src="' + esc(fileurl) + '" class="hof-cert-popup-iframe"'
                    + '          title="' + esc(title) + '" frameborder="0"></iframe>'
                    + '  <p class="hof-cert-popup-pdf-fallback">'
                    + '    If the PDF does not display, '
                    + '    <a href="' + esc(fileurl) + '" target="_blank" rel="noopener noreferrer">click here to open it</a>.'
                    + '  </p>'
                    + '</div>';
            }
        }

        _overlay.classList.add('hof-cert-overlay-open');
        document.body.classList.add('hof-body-modal-open');

        // Focus the close button for accessibility.
        var closeBtn = document.getElementById('hof-cert-popup-close');
        if (closeBtn) closeBtn.focus();
    }

    function closePopup() {
        if (!_overlay) return;
        _overlay.classList.remove('hof-cert-overlay-open');
        document.body.classList.remove('hof-body-modal-open');

        // Clear body so iframes stop loading.
        var bodyEl = document.getElementById('hof-cert-popup-body');
        if (bodyEl) bodyEl.innerHTML = '';
    }

    function esc(s) {
        if (!s) return '';
        return String(s)
            .replace(/&/g,'&amp;').replace(/</g,'&lt;')
            .replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
    }

    return {init: init};
});
