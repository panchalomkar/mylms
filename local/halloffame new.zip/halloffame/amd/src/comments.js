/**
 * Hall of Fame v3 – comments AMD module.
 * Handles loading, posting, and deleting comments via AJAX.
 * Works for both user-facing cards (awards/achievements) and admin review (submissions).
 *
 * @module local_halloffame/comments
 */
define(['core/ajax', 'core/notification'], function(Ajax, Notification) {
    'use strict';

    // Tracks which comment sections have already been loaded.
    var _loaded = {};

    function init() {
        // Toggle comment section when comment button is clicked.
        document.addEventListener('click', function(e) {
            var btn = e.target.closest('.hof-comment-btn');
            if (btn) {
                toggleComments(btn);
                return;
            }

            // Submit a comment.
            var submitBtn = e.target.closest('.hof-comment-submit');
            if (submitBtn) {
                submitComment(submitBtn);
                return;
            }

            // Delete a comment.
            var deleteBtn = e.target.closest('.hof-comment-delete-btn');
            if (deleteBtn) {
                deleteComment(deleteBtn);
                return;
            }
        });

        // Allow Ctrl+Enter to submit in textareas.
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
                var ta = e.target.closest('.hof-comment-input');
                if (ta) {
                    var itemid   = ta.dataset.id;
                    var itemtype = ta.dataset.type;
                    var submitBtn = ta.closest('.hof-comment-form')
                                     .querySelector('.hof-comment-submit');
                    if (submitBtn) submitComment(submitBtn);
                }
            }
        });

        // For admin review, auto-load existing comments on page load (they're SSR'd but keep AJAX sync).
        initAdminCommentForms();
    }

    /**
     * Wire up submit/delete on server-rendered admin comment forms.
     * (Admin review uses SSR comments — only dynamic interactions need wiring.)
     */
    function initAdminCommentForms() {
        document.querySelectorAll('.hof-comment-delete-btn').forEach(function(btn) {
            // Already handled by delegated listener above, just ensure no duplicates.
        });
    }

    // ── Toggle ────────────────────────────────────────────────────────────────

    function toggleComments(btn) {
        var itemid   = btn.dataset.id;
        var itemtype = btn.dataset.type;
        var key      = itemtype + '-' + itemid;
        var sectionId = 'hof-comments-' + itemtype + '-' + itemid;
        var section   = document.getElementById(sectionId);
        if (!section) return;

        var isHidden = section.style.display === 'none' || section.style.display === '';
        section.style.display = isHidden ? 'block' : 'none';

        if (isHidden && !_loaded[key]) {
            _loaded[key] = true;
            loadComments(itemid, itemtype);
        }
    }

    // ── Load ──────────────────────────────────────────────────────────────────

    function loadComments(itemid, itemtype) {
        var listId = 'hof-comments-list-' + itemtype + '-' + itemid;
        var list   = document.getElementById(listId);
        if (!list) return;

        list.innerHTML = '<div class="hof-comments-loading">'
            + '<i class="fa fa-spinner fa-spin" aria-hidden="true"></i></div>';

        Ajax.call([{
            methodname: 'local_halloffame_get_comments',
            args: {itemid: parseInt(itemid, 10), itemtype: itemtype}
        }])[0].then(function(comments) {
            renderComments(list, comments);
        }).catch(function(err) {
            list.innerHTML = '<p class="hof-comments-error">Could not load comments.</p>';
            Notification.exception(err);
        });
    }

    // ── Render ────────────────────────────────────────────────────────────────

    function renderComments(container, comments) {
        if (!comments || !comments.length) {
            container.innerHTML = '<p class="hof-comments-empty">No comments yet. Be the first!</p>';
            return;
        }
        container.innerHTML = '';
        comments.forEach(function(c) {
            container.insertAdjacentHTML('beforeend', buildCommentHtml(c));
        });
    }

    function buildCommentHtml(c) {
        var deleteBtn = c.canbedeleted
            ? '<button class="hof-comment-delete-btn" data-commentid="' + c.id
              + '" aria-label="Delete comment"><i class="fa fa-times" aria-hidden="true"></i></button>'
            : '';
        return '<div class="hof-comment-item" data-commentid="' + c.id + '">'
            + '<img src="' + esc(c.userpictureurl) + '" class="hof-comment-avatar" alt="' + esc(c.fullname) + '"/>'
            + '<div class="hof-comment-bubble">'
            + '<div class="hof-comment-meta">'
            + '<strong class="hof-comment-author">' + esc(c.fullname) + '</strong>'
            + '<span class="hof-comment-time">' + esc(c.timecreatedstr) + '</span>'
            + deleteBtn
            + '</div>'
            + '<p class="hof-comment-message">' + esc(c.message) + '</p>'
            + '</div></div>';
    }

    // ── Submit ────────────────────────────────────────────────────────────────

    function submitComment(submitBtn) {
        var form     = submitBtn.closest('.hof-comment-form');
        var textarea = form ? form.querySelector('.hof-comment-input') : null;
        if (!textarea) return;

        var itemid   = submitBtn.dataset.id;
        var itemtype = submitBtn.dataset.type;
        var message  = (textarea.value || '').trim();

        if (!message) {
            textarea.focus();
            textarea.classList.add('hof-input-error');
            setTimeout(function() { textarea.classList.remove('hof-input-error'); }, 1500);
            return;
        }

        submitBtn.disabled  = true;
        textarea.disabled   = true;
        var origText        = submitBtn.innerHTML;
        submitBtn.innerHTML = '<i class="fa fa-spinner fa-spin" aria-hidden="true"></i>';

        Ajax.call([{
            methodname: 'local_halloffame_add_comment',
            args: {itemid: parseInt(itemid, 10), itemtype: itemtype, message: message}
        }])[0].then(function(comment) {
            textarea.value    = '';
            submitBtn.disabled  = false;
            textarea.disabled   = false;
            submitBtn.innerHTML = origText;

            // Make sure section is visible.
            var sectionId = 'hof-comments-' + itemtype + '-' + itemid;
            var section   = document.getElementById(sectionId);
            if (section) section.style.display = 'block';

            // Append to the comment list.
            var listId = 'hof-comments-list-' + itemtype + '-' + itemid;
            var list   = document.getElementById(listId);
            if (list) {
                var emptyMsg = list.querySelector('.hof-comments-empty');
                if (emptyMsg) emptyMsg.remove();
                list.insertAdjacentHTML('beforeend', buildCommentHtml(comment));
                list.lastElementChild.scrollIntoView({behavior: 'smooth', block: 'nearest'});
            }

            // Update the comment count badge on the card button.
            var card = document.querySelector('.hof-award-card[data-id="' + itemid + '"],'
                + '.hof-ach-card[data-id="' + itemid + '"]');
            if (card) {
                var countEl = card.querySelector('.hof-comment-btn .hof-comment-count');
                if (countEl) countEl.textContent = parseInt(countEl.textContent || '0', 10) + 1;
            }

            _loaded[itemtype + '-' + itemid] = true;
        }).catch(function(err) {
            submitBtn.disabled  = false;
            textarea.disabled   = false;
            submitBtn.innerHTML = origText;
            Notification.exception(err);
        });
    }

    // ── Delete ────────────────────────────────────────────────────────────────

    function deleteComment(deleteBtn) {
        var commentid = parseInt(deleteBtn.dataset.commentid, 10);
        if (!commentid) return;
        if (!confirm('Delete this comment?')) return;

        deleteBtn.disabled = true;

        Ajax.call([{
            methodname: 'local_halloffame_delete_comment',
            args: {commentid: commentid}
        }])[0].then(function(res) {
            if (res.success) {
                var item = deleteBtn.closest('.hof-comment-item');
                if (item) {
                    item.style.opacity = '0';
                    item.style.transition = 'opacity .3s';
                    setTimeout(function() {
                        // Update count badge.
                        var list = item.closest('.hof-comments-list');
                        if (list) {
                            // Find the card this list belongs to and decrement the counter.
                            var card = item.closest('.hof-award-card, .hof-ach-card');
                            if (card) {
                                var countEl = card.querySelector('.hof-comment-btn .hof-comment-count');
                                if (countEl) {
                                    var n = parseInt(countEl.textContent || '1', 10);
                                    countEl.textContent = Math.max(0, n - 1);
                                }
                            }
                        }
                        item.remove();
                    }, 300);
                }
            }
        }).catch(function(err) {
            deleteBtn.disabled = false;
            Notification.exception(err);
        });
    }

    // ── Utility ───────────────────────────────────────────────────────────────

    function esc(s) {
        if (s === null || s === undefined) return '';
        return String(s)
            .replace(/&/g,'&amp;').replace(/</g,'&lt;')
            .replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
    }

    return {init: init};
});
