/**
 * Hall of Fame v2 – likes AMD module.
 * Handles like/unlike with optimistic UI.
 * Updated for FontAwesome icon buttons (fa-heart / fa-heart-o).
 *
 * @module local_halloffame/likes
 */
define(['core/ajax', 'core/notification'], function(Ajax, Notification) {
    'use strict';

    function init() {
        document.addEventListener('click', function(e) {
            var btn = e.target.closest('.hof-like-btn');
            if (!btn) return;
            var itemid   = parseInt(btn.dataset.id, 10);
            var itemtype = btn.dataset.type;
            if (!itemid || !itemtype) return;
            toggle(btn, itemid, itemtype);
        });
    }

    function toggle(btn, itemid, itemtype) {
        var countEl  = btn.querySelector('.hof-like-count');
        var wasLiked = btn.classList.contains('hof-liked');
        var oldCount = parseInt(countEl ? countEl.textContent : '0', 10) || 0;

        // Optimistic update
        btn.disabled = true;
        if (wasLiked) {
            btn.classList.remove('hof-liked');
            btn.setAttribute('aria-pressed', 'false');
            if (countEl) countEl.textContent = Math.max(0, oldCount - 1);
            swapIcon(btn, false, itemtype);
        } else {
            btn.classList.add('hof-liked');
            btn.setAttribute('aria-pressed', 'true');
            if (countEl) countEl.textContent = oldCount + 1;
            swapIcon(btn, true, itemtype);
            pop(btn);
        }

        Ajax.call([{
            methodname: 'local_halloffame_like_item',
            args: {itemid: itemid, itemtype: itemtype}
        }])[0].then(function(r) {
            btn.disabled = false;
            if (countEl) countEl.textContent = r.count;
            var nowLiked = !!r.liked;
            if (nowLiked) {
                btn.classList.add('hof-liked');
                btn.setAttribute('aria-pressed', 'true');
            } else {
                btn.classList.remove('hof-liked');
                btn.setAttribute('aria-pressed', 'false');
            }
            swapIcon(btn, nowLiked, itemtype);
        }).catch(function(err) {
            // Rollback
            btn.disabled = false;
            if (countEl) countEl.textContent = oldCount;
            if (wasLiked) { btn.classList.add('hof-liked'); swapIcon(btn, true, itemtype); }
            else          { btn.classList.remove('hof-liked'); swapIcon(btn, false, itemtype); }
            Notification.exception(err);
        });
    }

    /**
     * Swap FontAwesome icon between liked/unliked states.
     * Awards use fa-thumbs-up (always filled, colour changes via CSS).
     * Achievements use fa-heart / fa-heart-o.
     */
    function swapIcon(btn, liked, itemtype) {
        var icon = btn.querySelector('.fa');
        if (!icon) return;
        if (itemtype === 'achievement') {
            if (liked) {
                icon.classList.remove('fa-heart-o');
                icon.classList.add('fa-heart');
            } else {
                icon.classList.remove('fa-heart');
                icon.classList.add('fa-heart-o');
            }
        }
        // Awards: fa-thumbs-up stays; colour handled by .hof-liked CSS class.
    }

    function pop(btn) {
        btn.classList.add('hof-like-pop');
        btn.addEventListener('animationend', function h() {
            btn.classList.remove('hof-like-pop');
            btn.removeEventListener('animationend', h);
        });
    }

    return {init: init};
});
